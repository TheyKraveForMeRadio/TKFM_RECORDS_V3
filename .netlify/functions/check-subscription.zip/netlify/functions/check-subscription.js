var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var check_subscription_exports = {};
__export(check_subscription_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(check_subscription_exports);
var import_supabase = require("./supabase.js");
async function handler(event) {
  const email = event.queryStringParameters.email;
  const { data } = await import_supabase.supabase.from("tkfm_artists").select("subscription_active").eq("email", email).single();
  return {
    statusCode: 200,
    body: JSON.stringify({ active: data?.subscription_active || false })
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
