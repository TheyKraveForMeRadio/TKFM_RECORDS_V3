var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/event-artist-upload.js
var event_artist_upload_exports = {};
__export(event_artist_upload_exports, {
  default: () => event_artist_upload_default
});
module.exports = __toCommonJS(event_artist_upload_exports);
var BASE = process.env.SELF_BASE_URL || "https://tkfmrecords.com";
var event_artist_upload_default = async () => {
  const event = {
    type: "song_uploaded",
    catalog_id: "songABC",
    artist: "DJ KRAVE"
  };
  await fetch(BASE + "/.netlify/functions/tkfm-event-bus", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(event)
  });
  return {
    statusCode: 200,
    body: "upload event emitted"
  };
};
