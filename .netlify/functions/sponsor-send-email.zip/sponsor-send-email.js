var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var sponsor_send_email_exports = {};
__export(sponsor_send_email_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(sponsor_send_email_exports);
var import_resend = require("resend");
const resend = new import_resend.Resend(process.env.RESEND_API_KEY);
const handler = async (event) => {
  if (event.headers["x-owner-key"] !== process.env.TKFM_OWNER_KEY) {
    return { statusCode: 403, body: "Forbidden" };
  }
  const { email, audio_url, request_id } = JSON.parse(event.body);
  if (!email || !audio_url) {
    return { statusCode: 400, body: "Missing data" };
  }
  await resend.emails.send({
    from: process.env.FROM_EMAIL,
    to: email,
    subject: "\u{1F399}\uFE0F Your TKFM Sponsor Read Is Ready",
    html: `
      <h2>Your Sponsor Read Is Complete</h2>
      <p>Thanks for working with <b>They Krave For Me Radio</b>.</p>
      <p><a href="${audio_url}" target="_blank">\u{1F3A7} Click here to listen & download</a></p>
      <p>Request ID: <b>${request_id}</b></p>
      <hr/>
      <small>TKFM Radio \u2014 Independent Artist Power Station</small>
    `
  });
  return {
    statusCode: 200,
    body: JSON.stringify({ ok: true })
  };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
