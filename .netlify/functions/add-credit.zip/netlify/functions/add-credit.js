var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var add_credit_exports = {};
__export(add_credit_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(add_credit_exports);
var import_supabase = require("./supabase.js");
async function handler(event) {
  const { artist_email, credit_type, amount } = JSON.parse(event.body);
  const { data, error } = await import_supabase.supabase.from("tkfm_artists").select("credits").eq("email", artist_email).single();
  if (error) return { statusCode: 400, body: JSON.stringify(error) };
  const credits = data.credits || {};
  credits[credit_type] = (credits[credit_type] || 0) + amount;
  const { error: updateError } = await import_supabase.supabase.from("tkfm_artists").update({ credits }).eq("email", artist_email);
  if (updateError) return { statusCode: 400, body: JSON.stringify(updateError) };
  return { statusCode: 200, body: JSON.stringify({ success: true, credits }) };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
