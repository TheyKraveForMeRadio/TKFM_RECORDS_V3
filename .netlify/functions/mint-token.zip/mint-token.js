var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var mint_token_exports = {};
__export(mint_token_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(mint_token_exports);
var import_ethers = require("ethers");
var import_TKFMToken = __toESM(require("../../contracts/TKFMToken.json"));
async function handler(event) {
  const { artistAddress, tokenId, amount } = JSON.parse(event.body);
  if (!artistAddress || !tokenId || !amount) {
    return { statusCode: 400, body: JSON.stringify({ error: "Missing fields" }) };
  }
  try {
    const provider = new import_ethers.ethers.JsonRpcProvider(process.env.ETH_RPC_URL);
    const signer = new import_ethers.ethers.Wallet(process.env.OWNER_PRIVATE_KEY, provider);
    const contract = new import_ethers.ethers.Contract(process.env.TKFM_TOKEN_ADDRESS, import_TKFMToken.default, signer);
    const tx = await contract.mint(artistAddress, tokenId, amount);
    await tx.wait();
    return { statusCode: 200, body: JSON.stringify({ success: true, txHash: tx.hash }) };
  } catch (e) {
    return { statusCode: 500, body: JSON.stringify({ error: e.message }) };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
