var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/fan-portfolio.js
var fan_portfolio_exports = {};
__export(fan_portfolio_exports, {
  default: () => fan_portfolio_default
});
module.exports = __toCommonJS(fan_portfolio_exports);
var import_supabase_js = require("@supabase/supabase-js");
var supabase = (0, import_supabase_js.createClient)(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);
var fan_portfolio_default = async () => {
  const user = "demo-user";
  const { data } = await supabase.from("fan_portfolio").select("*").eq("user_id", user);
  return {
    statusCode: 200,
    body: JSON.stringify({
      portfolio: data || [],
      royalties: 120
    })
  };
};
