var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var kpi_metrics_exports = {};
__export(kpi_metrics_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(kpi_metrics_exports);
var import_supabase = require("./supabase.js");
async function handler(event) {
  try {
    const { data: artists } = await import_supabase.supabase.from("tkfm_artists").select("*");
    const { data: plays } = await import_supabase.supabase.from("tkfm_radio_plays").select("*");
    const { data: credits } = await import_supabase.supabase.from("tkfm_credit_usage").select("*");
    const kpi = artists.map((a) => {
      const artistPlays = plays.filter((p) => p.artist_email === a.email).length;
      const usedCredits = credits.filter((c) => c.artist_email === a.email);
      const creditSummary = usedCredits.reduce((acc, c) => {
        acc[c.credit_type] = (acc[c.credit_type] || 0) + 1;
        return acc;
      }, {});
      return { email: a.email, name: a.name, plays: artistPlays, creditsUsed: creditSummary };
    });
    return { statusCode: 200, body: JSON.stringify(kpi) };
  } catch (e) {
    return { statusCode: 500, body: JSON.stringify({ error: e.message }) };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
