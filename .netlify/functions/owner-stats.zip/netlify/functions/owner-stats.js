var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_stats_exports = {};
__export(owner_stats_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(owner_stats_exports);
var import_supabase_js = require("@supabase/supabase-js");
const supabase = (0, import_supabase_js.createClient)(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);
async function handler() {
  const { data: artists } = await supabase.from("tkfm_artists").select("*");
  const { data: plays } = await supabase.from("tkfm_radio_plays").select("*");
  const { data: credits } = await supabase.from("tkfm_credit_usage").select("*");
  const activeArtists = artists.filter((a) => a.subscription_active);
  const mrr = activeArtists.reduce((sum, a) => {
    if (a.label_plan === "monthly_premium") return sum + 149;
    return sum + 79;
  }, 0);
  return {
    statusCode: 200,
    body: JSON.stringify({
      overview: {
        total_artists: artists.length,
        active_subscriptions: activeArtists.length,
        estimated_mrr: mrr
      },
      artists,
      credits: {
        total_usage: credits.length,
        breakdown: credits.reduce((acc, c) => {
          acc[c.credit_type] = (acc[c.credit_type] || 0) + 1;
          return acc;
        }, {})
      },
      radio: {
        total_plays: plays.length
      }
    })
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
