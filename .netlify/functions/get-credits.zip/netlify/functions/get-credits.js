var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var get_credits_exports = {};
__export(get_credits_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(get_credits_exports);
var import_supabase = require("./supabase.js");
async function handler(event, context) {
  try {
    const { data, error } = await import_supabase.supabase.from("artist_credits").select("*");
    if (error) throw error;
    const result = {};
    data.forEach((row) => {
      if (!result[row.email]) result[row.email] = {};
      result[row.email][row.credit_key] = row.amount;
    });
    return {
      statusCode: 200,
      body: JSON.stringify(result)
    };
  } catch (e) {
    return { statusCode: 500, body: JSON.stringify({ error: e.message }) };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
