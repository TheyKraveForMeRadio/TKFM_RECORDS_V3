var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/catalog-market-data.js
var catalog_market_data_exports = {};
__export(catalog_market_data_exports, {
  default: () => handler
});
module.exports = __toCommonJS(catalog_market_data_exports);
var import_supabase_js = require("@supabase/supabase-js");

// netlify/functions/redis-cache.js
var import_ioredis = __toESM(require("ioredis"));
var redis;
function getRedis() {
  if (!redis) {
    redis = new import_ioredis.default(process.env.REDIS_URL, {
      tls: {},
      maxRetriesPerRequest: 3
    });
  }
  return redis;
}
async function cacheGet(key) {
  const r = getRedis();
  const value = await r.get(key);
  if (!value) return null;
  return JSON.parse(value);
}
async function cacheSet(key, value, ttl = 60) {
  const r = getRedis();
  await r.set(key, JSON.stringify(value), "EX", ttl);
}

// netlify/functions/catalog-market-data.js
var supabase = (0, import_supabase_js.createClient)(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);
async function handler() {
  const cacheKey = "market_data";
  const cached = await cacheGet(cacheKey);
  if (cached) {
    return {
      statusCode: 200,
      body: JSON.stringify(cached)
    };
  }
  const { data } = await supabase.from("catalogs").select("*").order("market_cap", { ascending: false }).limit(50);
  const response = { market: data || [] };
  await cacheSet(cacheKey, response, 10);
  return {
    statusCode: 200,
    body: JSON.stringify(response)
  };
}
